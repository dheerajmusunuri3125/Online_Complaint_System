package com.entity;

public enum  Priority {
	LOW,MEDIUM,HIGH
}
