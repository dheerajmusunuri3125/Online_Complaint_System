package com.entity;

public enum Status {

	OPEN,IN_PROGRESS,RESOLVED
}
